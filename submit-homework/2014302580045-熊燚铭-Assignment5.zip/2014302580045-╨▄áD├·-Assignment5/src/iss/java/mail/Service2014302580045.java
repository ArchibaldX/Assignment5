package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class Service2014302580045 implements IMailService {

	/**
	 * The properties used to send mails
	 */
	private Properties propertieTo=System.getProperties();

	/**
	 * The properties used to get mails
	 */
	private Properties propertiesGet=System.getProperties();

	/**
	 * The sending mails session 
	 */
	private Session sessionTO;

	/**
	 * The getting mails session 
	 */
	private Session sessionGet;

	/**
	 * Using to store contents in mail folder
	 */
	private Store store; 
	
	/**
	 * Acounts
	 */
	private String acount = null;

	/**
	 * Passward
	 */
	private String pwd = null;

	/**
	 * Init Properties
	 */
	private void init(String Count,String pwd){
		propertieTo.put("mail.smtp.auth", "true");
		propertieTo.put("mail.smtp.host", "smtp.sina.cn");
		propertiesGet.setProperty("mail.store.protocol", "imap");
		propertiesGet.setProperty("mail.imap.host", "imap.sina.cn");
		propertiesGet.setProperty("mail.imap.port", "143");	
		this.acount = Count;
		this.pwd = pwd;

	}

	/**
	 * @throws MessagingException
	 * Connect the message stored in folder
	 */
	private void connStore() throws MessagingException{
		store =sessionGet.getStore("imap");
		store.connect();
	}


	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#connect()
	 * Connect to the mail server
	 */
	@Override
	public void connect() throws MessagingException {
		init("17771842186@sina.cn","123456789");

		sessionTO=Session.getInstance(propertieTo,new MyAuthenticator());
		sessionGet=Session.getInstance(propertiesGet,new MyAuthenticator());
	}


	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#send(java.lang.String, java.lang.String, java.lang.Object)
	 * 	Sending mails	 
	 * */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		MimeMessage message = new MimeMessage(sessionTO);
		message.setFrom(new InternetAddress(acount));
		message.setSubject(subject);
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setContent(content.toString(), "text/html;charset=utf-8");
		Transport.send(message);
	}


	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#listen()
	 * Listen to the change of the folder
	 */
	@Override
	public boolean listen() throws MessagingException {
		connStore();
		Folder folder =store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		int num;
		num=folder.getUnreadMessageCount();
		if(num>0) {
			return true;
		}
		store.close();
		return false;
	}

	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#getReplyMessageContent(java.lang.String, java.lang.String)
	 *  Get the auto reply messages 
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		connStore();
		String str = new String();
		
		Folder folder =store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		
		Message[] messages=folder.getMessages();
		String content;
		for(int i=0;i<messages.length;i++){ 
			sender = "issjava2015@foxmail.com";
			subject = messages[i].getSubject().toString();
			content = messages[i].getContent().toString();
			str = "The sender is:"+sender+"\n"+"The subject is:"+subject+"\n"+"The content is:"+content;
		}	
		folder.close(false);
		store.close();
		return str;
	}

	/**
	 * @author Archibaldx
	 *	the Class used to create new authenticator
	 */
	class MyAuthenticator extends Authenticator{
		@Override
		protected PasswordAuthentication getPasswordAuthentication() {
			return new javax.mail.PasswordAuthentication(acount,pwd);
		}
	}



}
